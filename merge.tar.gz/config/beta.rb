SERVER_DOMAIN = "http://cos.sizl.org"
RESSI_URL = "http://cos.sizl.org/ressi"
CAS_BASE_URL = "https://cos.sizl.org:8443/cas"
