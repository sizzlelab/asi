SERVER_DOMAIN = "http://localhost:3000"
RESSI_URL = "http://localhost:9000"
