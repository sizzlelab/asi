SERVER_DOMAIN = "http://cos.alpha.sizl.org"
RESSI_URL = "http://cos.alpha.sizl.org/ressi"
