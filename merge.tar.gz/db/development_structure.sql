CREATE TABLE `actions` (
  `id` varchar(255) NOT NULL default '',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `action_type` varchar(255) default NULL,
  `action_value` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `addresses` (
  `id` int(11) NOT NULL auto_increment,
  `street_address` varchar(255) default NULL,
  `postal_code` varchar(255) default NULL,
  `locality` varchar(255) default NULL,
  `owner_id` int(11) default NULL,
  `owner_type` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_addresses_people` (`owner_id`),
  CONSTRAINT `fk_addresses_people` FOREIGN KEY (`owner_id`) REFERENCES `people` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=996332910 DEFAULT CHARSET=utf8;

CREATE TABLE `cached_cos_events` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` varchar(255) default NULL,
  `application_id` varchar(255) default NULL,
  `cos_session_id` varchar(255) default NULL,
  `ip_address` varchar(255) default NULL,
  `action` varchar(255) default NULL,
  `parameters` varchar(255) default NULL,
  `return_value` varchar(255) default NULL,
  `headers` text,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `semantic_event_id` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=362 DEFAULT CHARSET=utf8;

CREATE TABLE `channels` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `description` varchar(255) default NULL,
  `owner_id` int(11) default NULL,
  `channel_type` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `creator_app_id` varchar(255) default NULL,
  `guid` varchar(255) default NULL,
  `delta` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`id`),
  KEY `fk_channels_people` (`owner_id`),
  CONSTRAINT `fk_channels_people` FOREIGN KEY (`owner_id`) REFERENCES `people` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;

CREATE TABLE `client_data_sets` (
  `id` int(11) NOT NULL auto_increment,
  `client_id` varchar(255) default NULL,
  `person_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `data` text,
  PRIMARY KEY  (`id`),
  KEY `fk_client_data_sets_people` (`person_id`),
  CONSTRAINT `fk_client_data_sets_people` FOREIGN KEY (`person_id`) REFERENCES `people` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

CREATE TABLE `clients` (
  `id` varchar(255) NOT NULL default '',
  `name` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `encrypted_password` varchar(255) default NULL,
  `salt` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `collections` (
  `id` varchar(255) NOT NULL default '',
  `read_only` tinyint(1) default NULL,
  `client_id` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `owner_id` int(11) default NULL,
  `title` varchar(255) default NULL,
  `metadata` text,
  `indestructible` tinyint(1) default NULL,
  `tags` varchar(255) default NULL,
  `updated_by` varchar(255) default NULL,
  `priv` tinyint(1) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_collections_people` (`owner_id`),
  CONSTRAINT `fk_collections_people` FOREIGN KEY (`owner_id`) REFERENCES `people` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `condition_action_sets` (
  `id` int(11) NOT NULL auto_increment,
  `condition_id` varchar(255) default NULL,
  `action_id` varchar(255) default NULL,
  `rule_id` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1054583437 DEFAULT CHARSET=utf8;

CREATE TABLE `conditions` (
  `id` varchar(255) NOT NULL default '',
  `condition_type` varchar(255) default NULL,
  `condition_value` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `connections` (
  `id` int(11) NOT NULL auto_increment,
  `person_id` int(11) default NULL,
  `contact_id` int(11) default NULL,
  `status` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_connections_people_person` (`person_id`),
  KEY `fk_connections_people_contact` (`contact_id`),
  CONSTRAINT `fk_connections_people_contact` FOREIGN KEY (`contact_id`) REFERENCES `people` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_connections_people_person` FOREIGN KEY (`person_id`) REFERENCES `people` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1054583385 DEFAULT CHARSET=utf8;

CREATE TABLE `feedbacks` (
  `id` int(11) NOT NULL auto_increment,
  `content` text,
  `author_id` varchar(255) default NULL,
  `url` varchar(255) default NULL,
  `is_handled` int(11) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `group_search_handles` (
  `id` int(11) NOT NULL auto_increment,
  `group_id` varchar(255) default NULL,
  `delta` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

CREATE TABLE `group_subscriptions` (
  `id` int(11) NOT NULL auto_increment,
  `group_id` varchar(255) default NULL,
  `channel_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=701997482 DEFAULT CHARSET=utf8;

CREATE TABLE `groups` (
  `id` varchar(255) NOT NULL default '',
  `title` varchar(255) default NULL,
  `creator_id` int(11) default NULL,
  `group_type` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `description` text,
  PRIMARY KEY  (`id`),
  KEY `fk_groups_people` (`creator_id`),
  CONSTRAINT `fk_groups_people` FOREIGN KEY (`creator_id`) REFERENCES `people` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `images` (
  `id` varchar(255) NOT NULL default '',
  `filename` varchar(255) default NULL,
  `data` longblob,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `person_id` int(11) default NULL,
  `small_thumb` blob,
  `large_thumb` blob,
  PRIMARY KEY  (`id`),
  KEY `fk_images_people` (`person_id`),
  CONSTRAINT `fk_images_people` FOREIGN KEY (`person_id`) REFERENCES `people` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `locations` (
  `id` int(11) NOT NULL auto_increment,
  `person_id` int(11) default NULL,
  `latitude` decimal(15,12) default NULL,
  `longitude` decimal(15,12) default NULL,
  `label` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `accuracy` decimal(15,3) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_locations_people` (`person_id`),
  CONSTRAINT `fk_locations_people` FOREIGN KEY (`person_id`) REFERENCES `people` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1042391052 DEFAULT CHARSET=utf8;

CREATE TABLE `memberships` (
  `id` int(11) NOT NULL auto_increment,
  `person_id` int(11) default '0',
  `group_id` varchar(255) NOT NULL,
  `accepted_at` datetime default NULL,
  `admin_role` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `status` varchar(255) default NULL,
  `inviter_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_memberships_people_person` (`person_id`),
  KEY `fk_memberships_people_inviter` (`inviter_id`),
  CONSTRAINT `fk_memberships_people_inviter` FOREIGN KEY (`inviter_id`) REFERENCES `people` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_memberships_people_person` FOREIGN KEY (`person_id`) REFERENCES `people` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

CREATE TABLE `messages` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) default NULL,
  `content_type` varchar(255) default NULL,
  `body` text,
  `poster_id` int(11) default NULL,
  `channel_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `reference_to` int(11) default NULL,
  `attachment` varchar(255) default NULL,
  `guid` varchar(255) default NULL,
  `delta` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`id`),
  KEY `fk_messages_people` (`poster_id`),
  CONSTRAINT `fk_messages_people` FOREIGN KEY (`poster_id`) REFERENCES `people` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

CREATE TABLE `ownerships` (
  `id` int(11) NOT NULL auto_increment,
  `parent_id` varchar(255) default NULL,
  `item_id` varchar(255) default NULL,
  `item_type` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1054583385 DEFAULT CHARSET=utf8;

CREATE TABLE `pending_validations` (
  `id` int(11) NOT NULL auto_increment,
  `person_id` int(11) default NULL,
  `key` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_pending_validations_people` (`person_id`),
  CONSTRAINT `fk_pending_validations_people` FOREIGN KEY (`person_id`) REFERENCES `people` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=953125642 DEFAULT CHARSET=utf8;

CREATE TABLE `people` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(255) default NULL,
  `encrypted_password` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `email` varchar(255) default NULL,
  `salt` varchar(255) default NULL,
  `consent` varchar(255) default NULL,
  `coin_amount` int(11) NOT NULL default '0',
  `is_association` tinyint(1) default NULL,
  `status_message` varchar(255) default NULL,
  `status_message_changed` datetime default NULL,
  `gender` varchar(255) default NULL,
  `irc_nick` varchar(255) default NULL,
  `msn_nick` varchar(255) default NULL,
  `phone_number` varchar(255) default NULL,
  `description` text,
  `website` varchar(255) default NULL,
  `birthdate` date default NULL,
  `guid` varchar(255) default NULL,
  `delta` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`id`),
  KEY `index_people_on_guid` (`guid`)
) ENGINE=InnoDB AUTO_INCREMENT=2932 DEFAULT CHARSET=utf8;

CREATE TABLE `person_names` (
  `id` int(11) NOT NULL auto_increment,
  `given_name` varchar(255) default '',
  `family_name` varchar(255) default '',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `person_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_person_names_people` (`person_id`),
  CONSTRAINT `fk_person_names_people` FOREIGN KEY (`person_id`) REFERENCES `people` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=230965 DEFAULT CHARSET=utf8;

CREATE TABLE `person_specs` (
  `id` int(11) NOT NULL auto_increment,
  `person_id` int(11) default NULL,
  `status_message` varchar(255) default '',
  `birthdate` date default NULL,
  `gender` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `status_message_changed` datetime default NULL,
  `irc_nick` varchar(255) default NULL,
  `msn_nick` varchar(255) default NULL,
  `phone_number` varchar(255) default NULL,
  `description` varchar(255) default NULL,
  `website` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_person_specs_people` (`person_id`),
  CONSTRAINT `fk_person_specs_people` FOREIGN KEY (`person_id`) REFERENCES `people` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

CREATE TABLE `roles` (
  `id` int(11) NOT NULL auto_increment,
  `person_id` int(11) default NULL,
  `client_id` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `terms_version` varchar(255) default NULL,
  `location_security_token` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_roles_people` (`person_id`),
  CONSTRAINT `fk_roles_people` FOREIGN KEY (`person_id`) REFERENCES `people` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

CREATE TABLE `rules` (
  `id` varchar(255) NOT NULL default '',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `person_id` varchar(255) default NULL,
  `rule_name` varchar(255) default NULL,
  `state` varchar(255) default NULL,
  `logic` varchar(255) default 'And',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `schema_migrations` (
  `version` varchar(255) NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `sessions` (
  `id` int(11) NOT NULL auto_increment,
  `person_id` int(11) default NULL,
  `ip_address` varchar(255) default NULL,
  `path` varchar(255) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `client_id` varchar(255) default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_sessions_people` (`person_id`),
  CONSTRAINT `fk_sessions_people` FOREIGN KEY (`person_id`) REFERENCES `people` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31247 DEFAULT CHARSET=utf8;

CREATE TABLE `text_items` (
  `id` varchar(255) NOT NULL default '',
  `text` text,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `user_subscriptions` (
  `id` int(11) NOT NULL auto_increment,
  `person_id` int(11) default NULL,
  `channel_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `fk_user_subscriptions_people` (`person_id`),
  CONSTRAINT `fk_user_subscriptions_people` FOREIGN KEY (`person_id`) REFERENCES `people` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=404384831 DEFAULT CHARSET=utf8;

INSERT INTO schema_migrations (version) VALUES ('20080616101055');

INSERT INTO schema_migrations (version) VALUES ('20080616120429');

INSERT INTO schema_migrations (version) VALUES ('20080617073013');

INSERT INTO schema_migrations (version) VALUES ('20080617073028');

INSERT INTO schema_migrations (version) VALUES ('20080617073034');

INSERT INTO schema_migrations (version) VALUES ('20080617103442');

INSERT INTO schema_migrations (version) VALUES ('20080617122819');

INSERT INTO schema_migrations (version) VALUES ('20080619071224');

INSERT INTO schema_migrations (version) VALUES ('20080619105030');

INSERT INTO schema_migrations (version) VALUES ('20080623102903');

INSERT INTO schema_migrations (version) VALUES ('20080623110210');

INSERT INTO schema_migrations (version) VALUES ('20080623120054');

INSERT INTO schema_migrations (version) VALUES ('20080623141403');

INSERT INTO schema_migrations (version) VALUES ('20080624113429');

INSERT INTO schema_migrations (version) VALUES ('20080627080113');

INSERT INTO schema_migrations (version) VALUES ('20080627080339');

INSERT INTO schema_migrations (version) VALUES ('20080627094307');

INSERT INTO schema_migrations (version) VALUES ('20080627095305');

INSERT INTO schema_migrations (version) VALUES ('20080627115227');

INSERT INTO schema_migrations (version) VALUES ('20080630052354');

INSERT INTO schema_migrations (version) VALUES ('20080702095516');

INSERT INTO schema_migrations (version) VALUES ('20080702095636');

INSERT INTO schema_migrations (version) VALUES ('20080702130342');

INSERT INTO schema_migrations (version) VALUES ('20080703053611');

INSERT INTO schema_migrations (version) VALUES ('20080709123150');

INSERT INTO schema_migrations (version) VALUES ('20080710134252');

INSERT INTO schema_migrations (version) VALUES ('20080711095126');

INSERT INTO schema_migrations (version) VALUES ('20080711110350');

INSERT INTO schema_migrations (version) VALUES ('20080711112930');

INSERT INTO schema_migrations (version) VALUES ('20080711125113');

INSERT INTO schema_migrations (version) VALUES ('20080821135845');

INSERT INTO schema_migrations (version) VALUES ('20080828073648');

INSERT INTO schema_migrations (version) VALUES ('20080905101925');

INSERT INTO schema_migrations (version) VALUES ('20080909140722');

INSERT INTO schema_migrations (version) VALUES ('20080909140936');

INSERT INTO schema_migrations (version) VALUES ('20080909141012');

INSERT INTO schema_migrations (version) VALUES ('20080919102904');

INSERT INTO schema_migrations (version) VALUES ('20081006070657');

INSERT INTO schema_migrations (version) VALUES ('20081006155033');

INSERT INTO schema_migrations (version) VALUES ('20081013110859');

INSERT INTO schema_migrations (version) VALUES ('20081103091126');

INSERT INTO schema_migrations (version) VALUES ('20081124123300');

INSERT INTO schema_migrations (version) VALUES ('20081126131513');

INSERT INTO schema_migrations (version) VALUES ('20081215140355');

INSERT INTO schema_migrations (version) VALUES ('20090119153454');

INSERT INTO schema_migrations (version) VALUES ('20090225142651');

INSERT INTO schema_migrations (version) VALUES ('20090303143106');

INSERT INTO schema_migrations (version) VALUES ('20090304141330');

INSERT INTO schema_migrations (version) VALUES ('20090316080225');

INSERT INTO schema_migrations (version) VALUES ('20090331140757');

INSERT INTO schema_migrations (version) VALUES ('20090331202222');

INSERT INTO schema_migrations (version) VALUES ('20090522072331');

INSERT INTO schema_migrations (version) VALUES ('20090522082349');

INSERT INTO schema_migrations (version) VALUES ('20090622105927');

INSERT INTO schema_migrations (version) VALUES ('20090622105942');

INSERT INTO schema_migrations (version) VALUES ('20090622110052');

INSERT INTO schema_migrations (version) VALUES ('20090622110133');

INSERT INTO schema_migrations (version) VALUES ('20090625061648');

INSERT INTO schema_migrations (version) VALUES ('20090625064332');

INSERT INTO schema_migrations (version) VALUES ('20090630085402');

INSERT INTO schema_migrations (version) VALUES ('20090630085600');

INSERT INTO schema_migrations (version) VALUES ('20090630085637');

INSERT INTO schema_migrations (version) VALUES ('20090630130433');

INSERT INTO schema_migrations (version) VALUES ('20090701134634');

INSERT INTO schema_migrations (version) VALUES ('20090706061821');

INSERT INTO schema_migrations (version) VALUES ('20090706062003');

INSERT INTO schema_migrations (version) VALUES ('20090709194544');

INSERT INTO schema_migrations (version) VALUES ('20090710090910');

INSERT INTO schema_migrations (version) VALUES ('20090710093048');

INSERT INTO schema_migrations (version) VALUES ('20090710093230');

INSERT INTO schema_migrations (version) VALUES ('20090710094120');

INSERT INTO schema_migrations (version) VALUES ('20090710094648');

INSERT INTO schema_migrations (version) VALUES ('20090710105820');

INSERT INTO schema_migrations (version) VALUES ('20090715130508');

INSERT INTO schema_migrations (version) VALUES ('20090723092040');

INSERT INTO schema_migrations (version) VALUES ('20090723113212');

INSERT INTO schema_migrations (version) VALUES ('20090724092047');

INSERT INTO schema_migrations (version) VALUES ('20090724095426');

INSERT INTO schema_migrations (version) VALUES ('20090724110000');

INSERT INTO schema_migrations (version) VALUES ('20090724112520');

INSERT INTO schema_migrations (version) VALUES ('20090730064330');

INSERT INTO schema_migrations (version) VALUES ('20090730094346');

INSERT INTO schema_migrations (version) VALUES ('20090730101818');

INSERT INTO schema_migrations (version) VALUES ('20090730134109');

INSERT INTO schema_migrations (version) VALUES ('20090804082316');

INSERT INTO schema_migrations (version) VALUES ('20090805082702');

INSERT INTO schema_migrations (version) VALUES ('20090805084200');

INSERT INTO schema_migrations (version) VALUES ('20090810092748');

INSERT INTO schema_migrations (version) VALUES ('20090810135605');

INSERT INTO schema_migrations (version) VALUES ('20090817053708');

INSERT INTO schema_migrations (version) VALUES ('20090820083314');

INSERT INTO schema_migrations (version) VALUES ('20090820083341');