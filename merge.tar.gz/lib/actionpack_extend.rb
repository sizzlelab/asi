module ActionView
  module Helpers
    module TagHelper
      module_function :escape_once
    end
  end
end