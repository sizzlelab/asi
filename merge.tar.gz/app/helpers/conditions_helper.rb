module ConditionsHelper
end
