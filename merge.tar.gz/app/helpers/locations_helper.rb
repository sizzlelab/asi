module LocationsHelper
end
