module Coreui::ProfileHelper
end
