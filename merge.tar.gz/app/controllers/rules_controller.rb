class RulesController < ApplicationController
  layout "rules"
  before_filter :ensure_client_login, :except => [:create_default_profile_rule]

  PROFILE_FIELDS = %W(id username email name status_message birthdate phone_number gender irc_nick msn_nick avatar address location)

  def new
    if @user
      @person = Person.find_by_id(@user.id)

      @rule = Rule.new
      @rule.condition_action_sets.build

      @action = Action.find(:all)
      @condition = Condition.find(:all)
      @options = ""
      @condition.each do |condition|
        #determine the value for the selected option as "condition_type condition_value"
        @options = @options << "<option value='"+condition.condition_type+" "+condition.condition_value+"'>"
        #determine what will appear as an option
        if (condition.condition_type == "group") or (condition.condition_type == "user")
          @options = @options << condition.condition_type+" = "+condition.condition_value+"</option>"
        elsif (condition.condition_type == "logged_in") or (condition.condition_type == "is_friend")
          @options = @options << condition.condition_type+"</option>"
        else
          @options = @options << condition.condition_value+"</option>"
        end
      end
    end
  end

  def update_condition_value
    # updates condition_value based on condition_type selected
    @condition_value  = Condition.find(:all, :conditions => { :condition_type => params[:condition_type]})
    render :action => "update_condition_value.js.rjs"

#    render :update do |page|
#        page.replace_html 'condition_value_id', :partial => 'condition_value'
#    end
  end

  # create a new rule from create_rule view
  def create
    parameters_hash = HashWithIndifferentAccess.new(params.clone)
    params = fix_utf8_characters(parameters_hash) #fix nordic letters in person details
    @rule = Rule.new(params[:rule])
    @rule.state = "active"
    @rule.person_id = params[:user_id]

    #create hash with pairs of condition type and value from the view
    conditions_type_and_value = {}
    n = 0
    params[:condition].each do |field|
      teste = field.split(" ")
      conditions_type_and_value.merge!({teste[1] => teste[0]})
        n = n + 1
    end
    #loop trough the hash and create the condition_action_set
    conditions_type_and_value.each_pair do |value, type|
      condition = Condition.find_by_condition_type_and_condition_value(type, value)
      action = Action.find_by_action_type_and_action_value("view", params[:action_data])
      @rule.condition_action_sets.build(:condition_id => condition.id, :action_id => action.id)
    end
    #this way to create the rule could have performance improvemnt because
    #we call select for the same data two times. When we create the hash and when we loop trough the hash
    #The code could also be improved and cleaned if we remove the variable "n"

    if @rule.save
      flash[:notice] = "Successfully created rule."
      redirect_to rules_path
    else
      flash[:notice] = "Error."
      redirect_to :back
    end
  end

  # put in controller only for test purposes
  # when a new user is created, a default profile rule with rule name "profile
  # rule"is automatically created for him.
  # The user can edit the profile rule later
  # default profile rule sets profile fieds username 'public', and all
  # the other fields "private"
  def create_default_profile_rule
    parameters_hash = HashWithIndifferentAccess.new(params.clone)
    params = fix_utf8_characters(parameters_hash) #fix nordic letters in person details

    @rule = Rule.new(:person_id => params[:user_id],
                    :rule_name => "profile privacy",
                    :state => "active",
                    :logic => "and")

    # sets rule id as "person_id rule_name"
    # rule id cannot be set by "new", because id is protected attributes
    #@rule.id = params[:user_id] + " profile rule"
    # rule id is now generated automatically using 'usesguid' plugin

    # create condition_action_sets for this profile rule
    sets_hash = {}
    PROFILE_FIELDS.each do |field|
      if field == "username"
        sets_hash.merge!({field => "public"})
      else
        sets_hash.merge!({field => "private"})
      end
    end

    condition_public = Condition.find_by_condition_type_and_condition_value("publicity", "public")
    condition_private = Condition.find_by_condition_type_and_condition_value("publicity", "private")

    sets_hash.each_pair do |key, value|
      action = Action.find_by_action_type_and_action_value("view", key)
      if value == "public"
        condition_id = condition_public.id
      elsif value == "private"
        condition_id = condition_private.id
      end
      @rule.condition_action_sets.build(:condition_id => condition_id,
                                       :action_id => action.id)
    end

    if @rule.save
      flash[:notice] = "Default profile rule is created for user successfuly."
      redirect_to :back
    else
      flash[:notice] = "Default profile rule creation for user failed."
      redirect_to :back # not sure about this redirect_to
    end
  end

  # show all the rules belong to the user
  def index
    if @user
      @person = Person.find_by_id(@user.id)

      @rules = Rule.find_all_by_person_id(params[:user_id])
      @rules_hash = @rules.collect do |rule|
        rule.get_rule_hash(@user)
      end
    end
  end

  # show a rule
  # @condition_action_sets_hash = {action1=>conditions_array, action2=>conditions_array}
  def show
    if @user
      @person = Person.find_by_id(@user.id)
      @rule = Rule.find_by_id(params['id'])
      @condition_action_sets = @rule.get_condition_action_sets_belong_to_the_rule

      if ! @rule
        redirect_to rules_path
        flash[:notice] = "This rule doesn't exist."
      end
    end
  end

  #   update a rule, and associated conditon_action_sets
  def update
    @rule = Rule.find_by_id(params['id'])
    @rule.state = params['state']
    if @rule.update_attributes(params[:rule])
      flash[:notice] = 'Rule was successfully updated.'
    else
      flash[:notice] = 'Rule was successfully updated.'
    end
  end

  # distroy a rule and all the associated condition_action_sets
  def destroy
    @rule = Rule.find_by_id(params['id'])
    @rule.destroy
    if ! @rule
      render :status => :not_found and return
    end
    redirect_to rules_path
  end

  # enable a rule. set 'state' to 'active'
  def enable
    @rule = Rule.find_by_id(params['rule_id'])
    @rule.enable_rule
    redirect_to rules_path and return
  end

  # disable a rule. set 'state' to 'inactive'
  def disable
      @rule = Rule.find_by_id(params['rule_id'])
      @rule.disable_rule
      redirect_to rules_path and return
  end

end
