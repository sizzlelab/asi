class ConditionsController < ApplicationController

  # get_by_type_and_value(type, value)
  def get_by_type_and_value(type, value)

  end

  # create
  def create(type, value)

  end

  # update
  def update

  end

  # delete
  def delete
    
  end
end
