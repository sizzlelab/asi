# -*- coding: utf-8 -*-
class AppdataController < ApplicationController



=begin rapidoc
description:: Resources for application-specific data. Applications can save user-specific key–value data and generic data collections.
=end
  def index
  end

end
