class ActionsController < ApplicationController
  

  #get_by_model_and_field(moddel, field)
  def get_by_model_and_field(model, field)
  
  end

  # create
  def create(model, field)
    
  end

  # update
  def update()
    
  end

  # delete
  def delete()

  end
end
