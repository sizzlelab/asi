require 'test_helper'

class RulesHelperTest < ActionView::TestCase
end
