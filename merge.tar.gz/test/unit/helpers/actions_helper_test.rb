require 'test_helper'

class ActionsHelperTest < ActionView::TestCase
end
