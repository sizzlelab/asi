require 'test_helper'

class ApiControllerTest < ActionController::TestCase

  test "presence" do
    
  end

end
