require 'test_helper'
require 'json'

class RulesControllerTest < ActionController::TestCase

  fixtures :actions
  fixtures :conditions
  fixtures :condition_action_sets
  fixtures :rules
  fixtures :people
  fixtures :sessions

  # test create, params[:rule], params[:user_id]
  def test_create
    
      
  end

  # test create_default_profile_rule, params[:user_id]
  def test_create_default_profile_rule
      
      
  end


  # test index, params[:user_id]
  def test_index
    
  end


  # test show, params[:id]
  def test_show

  end


 # test update
  def test_update

  end


  # test destroy
  def test_destroy

  end


  # test enable, params[:rule_id]
  def test_enable

  end


  # test disable, params[:rule_id]
  def test_disable
    
  end
end
